import { execFileSync, spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import pg from 'pg';

const { Client } = pg;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const image = 'postgres:18.6';
const container = `time-interval-fixture-${process.pid}-${Date.now()}`;
const database = 'time_interval_fixture';
const schema = 'time_interval_constraint_fixture';
const password = randomBytes(24).toString('hex');
const resultPath = path.join(root, '.test-results.json');
const reportPath = path.join(root, 'verification', 'runner-result.md');
let port;
let digest = 'unknown';
let postgresVersion = 'unknown';
let migrationExit = null;
let testExit = null;
let testStarted = false;
let testResultsValid = false;
let containerCleanup = 'not attempted';
const resultCleanup = [];

function run(command, args, options = {}) {
  return execFileSync(command, args, { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], ...options });
}

function runInherit(command, args, env) {
  const result = spawnSync(command, args, { cwd: root, env, stdio: 'inherit' });
  return result.status ?? 1;
}

function databaseUrl(databaseName = database) {
  return `postgres://postgres:${password}@127.0.0.1:${port}/${databaseName}`;
}

async function withTcpClient(databaseName, action, connectionTimeoutMillis = 1000) {
  const client = new Client({
    connectionString: databaseUrl(databaseName),
    connectionTimeoutMillis,
  });
  await client.connect();
  try {
    return await action(client);
  } finally {
    await client.end();
  }
}

async function waitForReady() {
  const deadline = Date.now() + 30_000;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const result = await withTcpClient('postgres', (client) => client.query('SELECT 1 AS ready'));
      if (result.rows[0]?.ready === 1) return;
      lastError = new Error('TCP readiness query returned an unexpected value');
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  const detail = lastError instanceof Error ? `: ${lastError.message}` : '';
  throw new Error(`PostgreSQL did not accept a TCP SELECT 1 on 127.0.0.1:${port} within 30 seconds${detail}`);
}

async function removeResultFile(stage) {
  try {
    await unlink(resultPath);
    resultCleanup.push(`${stage}：已删除 ${path.basename(resultPath)}`);
  } catch (error) {
    if (error?.code === 'ENOENT') {
      resultCleanup.push(`${stage}：结果文件不存在，无需清理`);
      return;
    }
    const message = error instanceof Error ? error.message : String(error);
    resultCleanup.push(`${stage}：清理失败（${error?.code ?? 'unknown'}：${message}）`);
    throw error;
  }
}

function validateResults(value) {
  if (!value || !Array.isArray(value.outcomes) || value.outcomes.length === 0) {
    throw new Error('结果 JSON 缺少非空 outcomes 数组');
  }
  for (const outcome of value.outcomes) {
    if (!outcome || typeof outcome.name !== 'string' || !['passed', 'failed'].includes(outcome.status)) {
      throw new Error('结果 JSON 包含无效场景记录');
    }
  }
  return value;
}

async function loadCurrentResults() {
  if (!testStarted) return { results: null, reason: '测试未启动' };
  if (testExit !== 0) return { results: null, reason: `测试异常退出（退出码 ${testExit ?? '未知'}）` };
  try {
    const parsed = JSON.parse(await readFile(resultPath, 'utf8'));
    return { results: validateResults(parsed), reason: null };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return { results: null, reason: `测试未生成可解析的新结果：${message}` };
  }
}

async function writeReport() {
  const { results, reason } = await loadCurrentResults();
  testResultsValid = results !== null;
  try {
    await removeResultFile('运行后');
  } catch {
    // Cleanup failure is already recorded and must not hide the run outcome.
  }

  const passed = results?.outcomes.filter((outcome) => outcome.status === 'passed').length ?? 0;
  const failed = results?.outcomes.filter((outcome) => outcome.status === 'failed').length ?? 0;
  const lines = [
    '# Time Interval 约束原型一键运行报告',
    '',
    '- 本报告由 `pnpm prototype` 生成；不会覆盖手工审计报告 `result-report.md`。',
    `- PostgreSQL 镜像：\`${image}\``,
    `- 实际镜像 digest：\`${digest}\``,
    `- PostgreSQL Server 版本：\`${postgresVersion}\``,
    `- Node.js：\`${process.version}\``,
    '- 依赖：`node-pg-migrate@9.0.0`、`pg@8.23.0`',
    '- 迁移命令：`pnpm run migrate:up`',
    '- 测试命令：`pnpm test`',
    `- 数据库就绪路径：宿主机 TCP \`127.0.0.1:${port ?? '未分配'}\` 上执行 \`SELECT 1\``,
    `- 测试数据库：\`${database}\``,
    `- 测试 Schema：\`${schema}\``,
    '- 事务隔离级别：`READ COMMITTED`（测试连接显式设置并验证）',
    `- 迁移命令退出码：\`${migrationExit ?? '未执行'}\``,
    `- 测试命令退出码：\`${testExit ?? '未执行'}\``,
    `- 测试结果状态：${testResultsValid ? `有效（${results.outcomes.length} 个场景；${passed} 通过；${failed} 失败）` : `**未取得有效测试结果**（${reason}）`}`,
    `- 容器清理结果：${containerCleanup}`,
    `- 临时结果清理：${resultCleanup.join('；')}`,
    '',
    '## 场景结果',
    '',
    '| 场景 | 状态 | 关键证据 | 错误 | SQLSTATE | 约束 |',
    '|---|---|---|---|---|---|',
  ];
  for (const outcome of results?.outcomes ?? []) {
    lines.push(`| ${outcome.name} | ${outcome.status} | ${(outcome.evidence ?? '').replaceAll('|', '\\|')} | ${(outcome.error ?? '').replaceAll('|', '\\|')} | ${outcome.code ?? ''} | ${outcome.constraint ?? ''} |`);
  }
  if (!testResultsValid) lines.push(`| 未取得有效测试结果 | 未执行 | ${reason}；未读取或展示任何旧场景记录 | | | |`);
  lines.push('', '## 范围声明', '', '- 本原型只验证 Time Interval 来源绑定及最小依赖夹具。', '- 不代表正式生产 Schema，也不实现 Evidence、Projection Attempt 或完整 Canon Commit。');
  await mkdir(path.dirname(reportPath), { recursive: true });
  await writeFile(reportPath, `${lines.join('\n')}\n`);
}

async function main() {
  try {
    await removeResultFile('运行前');
    const imageInspect = JSON.parse(run('docker', ['image', 'inspect', image]))[0];
    digest = imageInspect.RepoDigests?.[0] ?? imageInspect.Id;
    run('docker', ['run', '-d', '--rm', '--name', container, '-e', `POSTGRES_PASSWORD=${password}`, '-p', '127.0.0.1::5432', image]);
    const portOutput = run('docker', ['port', container, '5432/tcp']).trim();
    const match = portOutput.match(/127\.0\.0\.1:(\d+)/);
    if (!match) throw new Error(`Unable to determine local port from docker port output: ${portOutput}`);
    port = Number(match[1]);
    await waitForReady();
    await withTcpClient('postgres', (client) => client.query(`CREATE DATABASE ${database}`));
    postgresVersion = await withTcpClient(database, async (client) => (await client.query('SHOW server_version')).rows[0].server_version);

    const env = { ...process.env, DATABASE_URL: databaseUrl(), PROTOTYPE_SCHEMA: schema, PROTOTYPE_RESULTS_PATH: resultPath };
    migrationExit = runInherit('pnpm', ['run', 'migrate:up'], env);
    if (migrationExit === 0) {
      testStarted = true;
      testExit = runInherit('pnpm', ['test'], env);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
    if (migrationExit === null) migrationExit = 1;
    if (testExit === null && testStarted) testExit = 1;
  } finally {
    try {
      run('docker', ['rm', '-f', container]);
      containerCleanup = `已删除本轮容器 ${container}；未执行全局 Docker 清理`;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      containerCleanup = `清理失败：请仅检查本轮容器 ${container}（${message}）`;
    }
    await writeReport();
  }
  if (migrationExit !== 0 || testExit !== 0 || !testResultsValid) process.exitCode = 1;
}

await main();
